package com.cg.dw.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.dw.exception.IBSException;
import com.cg.dw.model.CaseIdBean;
import com.cg.dw.model.CreditCardTransaction;
import com.cg.dw.model.DebitCardTransaction;

public interface BankService {

	public void setQueryStatus(String queryId, String newStatus, String remarks) throws IBSException;

	public String getNewQueryStatus(int newQueryStatus) throws IBSException;
	public void upgradeDC(String queryId) throws IBSException ;

	public void getNewDC(String queryId) throws IBSException;

	public void upgradeCC(String queryId) throws IBSException;

	public List<CaseIdBean> viewNewDebitQueries() throws IBSException;

	public List<CaseIdBean> viewNewCreditQueries() throws IBSException;

	public List<CaseIdBean> viewDebitUpgradeQueries() throws IBSException;

	public List<CaseIdBean> viewCreditUgradeQueries() throws IBSException;

	public List<CaseIdBean> viewDebitMismatchQueries() throws IBSException;

	public List<CaseIdBean> viewCreditMismatchQueries() throws IBSException;

	public boolean getBlockInput(int blockInput, BigInteger debitCardNumber) throws IBSException;

	public boolean getBlockInputCredit(int blockInput, BigInteger creditCardNumber) throws IBSException;
	
	public List<CreditCardTransaction> getCreditMismatchTransaction(BigInteger transactionId) throws IBSException;

	public boolean checkMismatchDebit(String queryId) throws IBSException;

	public List<DebitCardTransaction> getDebitMismatchTransaction(BigInteger mismatchTransactionId) throws IBSException;

	BigInteger getDebitTransactionId(String queryId) throws IBSException;

	public BigInteger getCreditTransactionId(String queryId) throws IBSException;

	boolean checkMismatchCredit(String queryId) throws IBSException;

	void blockDebit(BigInteger debitCardNumber) throws IBSException;

	void blockCredit(BigInteger creditCardNumber) throws IBSException;
}