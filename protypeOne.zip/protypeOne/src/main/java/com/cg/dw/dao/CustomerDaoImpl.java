package com.cg.dw.dao;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.dw.exception.IBSException;
import com.cg.dw.model.CustomerBean;

@Repository
public class CustomerDaoImpl implements CustomerDao {

	@PersistenceContext
	private EntityManager entityManager;

	

	//private static Logger logger = Logger.getLogger(CustomerDaoImpl.class);

	@Override
	public String getNewName(BigInteger uci) throws IBSException {
		//logger.info("entered into getNewName method of CustomerDaoImpl class");
		String fname = null;
		String lname = null;
		CustomerBean customer = null;

		TypedQuery<CustomerBean> query = entityManager.createQuery("select c from CustomerBean c where c.UCI=:uci",
				CustomerBean.class);

		query.setParameter("uci", uci);
		try {
			customer = query.getSingleResult();
			fname = customer.getFirstName();
			lname = customer.getLastName();
		} catch (NoResultException e) {

		}

		return (fname + " " + lname);

	}

	@Override
	public boolean verifyUCI(BigInteger uci) throws IBSException {
	//	logger.info("entered into verifyUCI method of CustomerDaoImpl class");

		boolean result = false;

		CustomerBean d = entityManager.find(CustomerBean.class, uci);

		if (d != null) {
			result = true;
		}

		return result;

	}
}