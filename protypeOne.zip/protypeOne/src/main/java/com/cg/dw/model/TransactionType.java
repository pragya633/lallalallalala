package com.cg.dw.model;

public enum TransactionType {
	CREDIT, DEBIT;

}
