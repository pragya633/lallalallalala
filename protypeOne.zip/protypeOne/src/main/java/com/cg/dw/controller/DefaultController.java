package com.cg.dw.controller;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dw.exception.IBSException;
import com.cg.dw.model.CaseIdBean;
import com.cg.dw.service.CustomerService;

@Controller
//@RequestMapping("/default")
public class DefaultController {
	
	@Autowired
	private CustomerService customerService;

	@RequestMapping({"/","/home"})
	public String showHome(){
		return "homePage";
	}
	
	@RequestMapping("/menu")
	public String showMenu(){
		return "menuPage";
	}
	
	@RequestMapping("/customer")
	public ModelAndView showCardHome() {
		return new ModelAndView("cardsHomePage");
	}

	@RequestMapping("/cardChoice")
	public ModelAndView showCardHome1() {
		return new ModelAndView("cardMenuPage");
	}

	@RequestMapping("/debitCards")
	public ModelAndView showDebitCardHome() {
		return new ModelAndView("debitHomeMenuPage");
	}
	
	@RequestMapping("/creditCards")
	public ModelAndView showCreditCardHome() {
		return new ModelAndView("creditHomeMenuPage");
	}
	
	@RequestMapping("/banker")
	public ModelAndView showBankHome() {
		return new ModelAndView("bankHomePage");
	}
	@RequestMapping("/viewStatus")
    public ModelAndView showStatus() {
        return new ModelAndView("queryStatus");
    }
    
    @RequestMapping(value="/queryStatus" ,method=RequestMethod.POST)
    public ModelAndView viewQueryStatus(@RequestParam("UCI") BigInteger uci) {
         List<CaseIdBean> caseIdBeans;
            try {
                caseIdBeans = customerService.listAllQueries(uci);
            } catch (IBSException e) {
                String message = e.getMessage();
                return new ModelAndView("errorPage", "errorMessage", message);
            }
            return new ModelAndView("listServiceRequests", "output", caseIdBeans);
        
        
    }
    @RequestMapping(value = "/displayServiceRequests")
    public ModelAndView queryStatus(@RequestParam("customerRefId") String customerReferenceId) {
        String output = "";
        try {
        String status =customerService.viewServiceRequestStatus(customerReferenceId);
            output = "Status of your request is '"+status+"'";
            return new ModelAndView("outputPage", "output", output);
        } catch (IBSException e) {
            output = e.getMessage();
            return new ModelAndView("errorPage", "output", output);
        }
    }

 

    }


