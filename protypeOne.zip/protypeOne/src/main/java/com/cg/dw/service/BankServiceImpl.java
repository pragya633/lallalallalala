package com.cg.dw.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityTransaction;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dw.dao.CaseIdDao;
import com.cg.dw.dao.CreditCardDao;
import com.cg.dw.dao.CreditCardTransactionDao;
import com.cg.dw.dao.CustomerDao;
import com.cg.dw.dao.DebitCardDao;
import com.cg.dw.dao.DebitCardTransactionDao;
import com.cg.dw.exception.ErrorMessages;
import com.cg.dw.exception.IBSException;
import com.cg.dw.model.AccountBean;
import com.cg.dw.model.CaseIdBean;
import com.cg.dw.model.CreditCardBean;
import com.cg.dw.model.CreditCardTransaction;
import com.cg.dw.model.CustomerBean;
import com.cg.dw.model.DebitCardBean;
import com.cg.dw.model.DebitCardTransaction;

@Service
public class BankServiceImpl implements BankService {
//	private static Logger logger = Logger.getLogger(BankServiceImpl.class);
	@Autowired
	private CaseIdDao caseIdDao;
	@Autowired
	private DebitCardTransactionDao debitCardTransactionDao;
	@Autowired
	private CreditCardTransactionDao creditCardTransactionDao;
	@Autowired
	private DebitCardDao debitCardDao;
	@Autowired
	private CreditCardDao creditCardDao;
	@Autowired
	private CustomerDao customerDao;


	private EntityTransaction entityTransaction;

	

	Random random = new Random();

	public String getNewQueryStatus(int newQueryStatus) throws IBSException {
	//	logger.info("entered into getNewQueryStatus method of BankServiceImpl class");
		String queryStatus = newQueryStatus + "";
		Pattern pattern = Pattern.compile("[123]");
		Matcher matcher = pattern.matcher(queryStatus);
		if (!(matcher.find() && matcher.group().equals(queryStatus)))
			throw new IBSException("Not a valid input");

		switch (newQueryStatus) {
		case 1:

			queryStatus = "Approved";
			break;
		case 2:
			queryStatus = "In Process";
			break;
		case 3:
			queryStatus = "Disapproved";
			break;
		default:
			queryStatus = "Pending";
			break;

		}
		return queryStatus;
	}
@Transactional
	@Override
	public void setQueryStatus(String queryId, String newStatus, String remarks) throws IBSException {
	//	logger.info("entered into setQueryStatus method of BankServiceImpl class");
		try {
			caseIdDao.setQueryStatus(queryId, newStatus, remarks);
			if (newStatus.contains("Approved")) {
				if (queryId.contains("ANDC")) {
					getNewDC(queryId);
				} else if (queryId.contains("ANCC")) {
					getNewCC(queryId);
				}

				else if (queryId.contains("RDCU")) {

					upgradeDC(queryId);
				} else if (queryId.contains("RCCU")) {
					upgradeCC(queryId);
				}

			}
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
	}

	@Override
	@Transactional
	public void upgradeCC(String queryId) throws IBSException {
		//logger.info("entered into upgradeCC method of BankServiceImpl class");
		try {
			creditCardDao.actionUpgradeCC(queryId);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
	}
@Override
@Transactional
	public void upgradeDC(String queryId) throws IBSException {
		//logger.info("entered into upgradeDC method of BankServiceImpl class");
		try {
			debitCardDao.actionUpgradeDC(queryId);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

	}

	private void getNewCC(String queryId) throws IBSException {
		//logger.info("entered into getNewCC method of BankServiceImpl class");

		try {
		CaseIdBean	obj = caseIdDao.getCaseObj(queryId);

			CustomerBean customBean = new CustomerBean();
			customBean.setUCI((obj.getCustomerBeanObject().getUCI()));
			CreditCardBean bean1 = new CreditCardBean();
			bean1.setCustBeanObject(customBean);
			bean1.setNameOnCard(customerDao.getNewName(caseIdDao.getNewUCI(queryId)));
			String cvv = String.format("%03d", random.nextInt(1000));
			bean1.setCvvNum(cvv);
			String pin = String.format("%04d", random.nextInt(10000));
			bean1.setCurrentPin(pin);
			Long first14 = (long) (Math.random() * 100000000000000L);
			Long number = 5200000000000000L + first14;
			BigInteger creditCardNumber = BigInteger.valueOf(number);
			bean1.setCardNumber(creditCardNumber);
			String scoreString = String.format("%04d", random.nextInt(1000));
			int score = Integer.parseInt(scoreString);
			bean1.setCreditScore(score);
			String incomeString = String.format("%04d", random.nextInt(100000));
			double income = Integer.parseInt(incomeString);
			bean1.setIncome(income);
			String status = "Active";
			bean1.setCardStatus(status);
			LocalDate expiry = LocalDate.now().plusYears(5);
			bean1.setDateOfExpiry(expiry);
			String type = caseIdDao.getNewType(queryId);
			if (type.equals("Platinum")) {
				bean1.setCardType("Platinum");
				bean1.setCreditLimit(new BigDecimal(500000));
			} else if (type.equals("Gold")) {
				bean1.setCardType("Gold");
				bean1.setCreditLimit(new BigDecimal(100000));
			} else if (type.equals("Silver")) {
				bean1.setCardType("Silver");
				bean1.setCreditLimit(new BigDecimal(50000));
			}
			entityTransaction.begin();
			creditCardDao.actionANCC(bean1);
			entityTransaction.commit();

		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

	}

	@Override
	public void getNewDC(String queryId) throws IBSException {
	//	logger.info("entered into getNewDC method of BankServiceImpl class");
		DebitCardBean bean = new DebitCardBean();
		AccountBean accountBean = new AccountBean();
		try {
			BigInteger uci = caseIdDao.getNewUCI(queryId);
			String name = customerDao.getNewName(uci);
		
			bean.setNameOnCard(name);
			bean.setCvvNum(String.format("%03d", random.nextInt(1000)));
		CaseIdBean	obj = caseIdDao.getCaseObj(queryId);

			accountBean.setAccountNumber(obj.getAccountNumber());
			
			bean.setAccountBeanObject(accountBean);
			bean.setCurrentPin(String.format("%04d", random.nextInt(10000)));
			Long first14 = (long) (Math.random() * 100000000000000L);
			Long number = 5200000000000000L + first14;
			BigInteger debitCardNumber = BigInteger.valueOf(number);
			bean.setCardNumber(debitCardNumber);
			String status = "Active";
			bean.setCardStatus(status);
			LocalDate expiry = LocalDate.now().plusYears(5);
			bean.setDateOfExpiry(expiry);
			String type = caseIdDao.getNewType(queryId);
			
			if (type.equals("Platinum")) {
				bean.setCardType("Platinum");
			} else if (type.equals("Gold")) {
				bean.setCardType("Gold");
			} else if (type.equals("Silver")) {
				bean.setCardType("Silver");
			}
			debitCardDao.actionANDC(bean);

		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

	}

	@Override
	public List<CaseIdBean> viewNewDebitQueries() throws IBSException {

		List<CaseIdBean> requests = null;
		try {
			requests = caseIdDao.viewNewdebitQueries();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return requests;
	}

	@Override
	public List<CaseIdBean> viewNewCreditQueries() throws IBSException {
		List<CaseIdBean> requests = null;
		try {
			requests = caseIdDao.viewNewCreditQueries();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return requests;
	}

	@Override
	public List<CaseIdBean> viewDebitUpgradeQueries() throws IBSException {
		List<CaseIdBean> requests = null;
		try {
			requests = caseIdDao.viewDebitUpgradeQueries();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return requests;
	}

	@Override
	public List<CaseIdBean> viewCreditUgradeQueries() throws IBSException {
		List<CaseIdBean> requests = null;
		try {
			requests = caseIdDao.viewCreditUpgradeQueries();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return requests;
	}

	@Override
	public List<CaseIdBean> viewDebitMismatchQueries() throws IBSException {
		List<CaseIdBean> requests = null;
		try {
			requests = caseIdDao.viewDebitMismatchQueries();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return requests;
	}

	@Override
	public List<CaseIdBean> viewCreditMismatchQueries() throws IBSException {
		List<CaseIdBean> requests = null;
		try {
			requests = caseIdDao.viewCreditMismatchQueries();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return requests;
	}

	@Override
	public boolean getBlockInput(int blockInput, BigInteger debitCardNumber) throws IBSException {

		boolean result = false;
		String blockString = blockInput + "";
		Pattern pattern = Pattern.compile("[12]");
		Matcher matcher = pattern.matcher(blockString);
		if (!(matcher.find() && matcher.group().equals(blockString))) {
			throw new IBSException("Not a valid input");
		}
		if (blockInput == 1) {
			debitCardDao.blockDebitCard(debitCardNumber);
			result = true;
		}
		return result;
	}

	@Override
	public BigInteger getDebitTransactionId(String queryId) throws IBSException {
	
		BigInteger transactionId = null;
		try {
			transactionId = debitCardTransactionDao.getDebitMismatchTranscId(queryId);
		
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
		return transactionId;
	}

	@Override
	public boolean getBlockInputCredit(int blockInput, BigInteger creditCardNumber) throws IBSException {
		boolean result = false;
		String blockString = blockInput + "";
		Pattern pattern = Pattern.compile("[12]");
		Matcher matcher = pattern.matcher(blockString);
		if (!(matcher.find() && matcher.group().equals(blockString))) {
			throw new IBSException("Not a valid input");
		}
		if (blockInput == 1) {
			creditCardDao.blockCreditCard(creditCardNumber);
			result = true;
		}
		return result;
	}

	@Override
	public List<CreditCardTransaction> getCreditMismatchTransaction(BigInteger transactionId) throws IBSException {
		List<CreditCardTransaction> creditCardBeanTrns = creditCardTransactionDao
				.getCreditMismatchTransc(transactionId);
		if (creditCardBeanTrns.isEmpty())
			throw new IBSException("NO TRANSACTIONS");
		return creditCardBeanTrns;
	}

    @Override
    public void blockDebit(BigInteger debitCardNumber) throws IBSException{
        debitCardDao.blockDebitCard(debitCardNumber);
    }

    @Override
    public void blockCredit(BigInteger creditCardNumber) throws IBSException{
        creditCardDao.blockCreditCard(creditCardNumber);
    }
 

	@Override
	public boolean checkMismatchDebit(String queryId) {

		boolean result = false;
		if (queryId.contains("RDMT")) {
			result = true;
		}
		return result;

	}

	@Override
	public boolean checkMismatchCredit(String queryId) {
		boolean result = false;
		if (queryId.contains("RCMT")) {
			result = true;
		}
		return result;
	}

	@Override
	public List<DebitCardTransaction> getDebitMismatchTransaction(BigInteger mismatchTransactionId)
			throws IBSException {
		List<DebitCardTransaction> debitCardBeanTrns = debitCardTransactionDao
				.getDebitMismatchTransc(mismatchTransactionId);
		if (debitCardBeanTrns.isEmpty())
			throw new IBSException("NO TRANSACTIONS");
		return debitCardBeanTrns;
	}

	@Override
	public BigInteger getCreditTransactionId(String queryId) throws IBSException {
		BigInteger transactionId = null;
		try {
			transactionId = creditCardTransactionDao.getCreditMismatchTranscId(queryId);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
		return transactionId;
	}

}