package com.cg.dw.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="depts")
@NamedQueries({
	@NamedQuery(name="findAllQry",query="select d from Department d"),
	@NamedQuery(name="findAllByNameQry",query="select d from Department d where d.dName=:dName")
})
public class Department {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="deptIdGenerator")
	@SequenceGenerator(name="deptIdGenerator",sequenceName="deptIdSeq",initialValue=100)
	private Long deptNo;
	private String dName;
	private String headOffice;

	public Long getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(Long deptNo) {
		this.deptNo = deptNo;
	}
	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}
	public String getHeadOffice() {
		return headOffice;
	}
	public void setHeadOffice(String headOffice) {
		this.headOffice = headOffice;
	}
}
